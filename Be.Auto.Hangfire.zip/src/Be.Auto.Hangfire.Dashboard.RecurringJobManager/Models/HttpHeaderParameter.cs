﻿namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models;



internal class HttpHeaderParameter
{
    public string Name { get; set; }
    public string Value { get; set; }
   
}