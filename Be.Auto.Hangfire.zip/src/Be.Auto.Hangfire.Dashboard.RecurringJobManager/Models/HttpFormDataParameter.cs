﻿namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models;

internal class HttpFormDataParameter
{
    public string Name { get; set; }
    public string Value { get; set; }
    public string ContentType { get; set; }

}