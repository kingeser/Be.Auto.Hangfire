﻿namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models;

internal class HttpFormUrlEncodedParameter
{
    public string Name { get; set; }
    public string Value { get; set; }

}