﻿namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models
{
    internal class Response
    {
        public bool Status { get; set; }

        public object Object { get; set; }

        public string Message { get; set; }
    }
}
