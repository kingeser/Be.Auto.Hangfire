﻿namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models.Enums;

internal enum ConcurrentJobExecution
{
    Allow,
    Disable
}