﻿using Be.Auto.Hangfire.Dashboard.RecurringJobManager.Models;

namespace Be.Auto.Hangfire.Dashboard.RecurringJobManager.Core;

internal static class Options
{
    internal static JobManagerOption Instance = new ();

}