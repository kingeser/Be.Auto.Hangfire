﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Sample.Pages
{
    public class IndexModel : PageModel
    {
     
        public void OnGet()
        {
            Redirect("/hangfire");
        }
    }
}
