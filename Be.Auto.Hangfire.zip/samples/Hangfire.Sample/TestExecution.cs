﻿using System;

namespace Sample
{
    public class TestExecutionJob
    {



        public void TestConsole()
        {
            Console.WriteLine("Testing Console");
        }

       
    }



}
